# Ansible Collection - my_own_namespace.my_own_collection

This is test ansible collection for netology homework 8.4
